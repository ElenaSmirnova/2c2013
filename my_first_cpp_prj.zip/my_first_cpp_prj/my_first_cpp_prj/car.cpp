#include "StdAfx.h"
#include "car.h"


car::car(int speed){
	this->speed = speed;
}

int car::get_speed(){
	return speed;
}

car::~car(void){
}
