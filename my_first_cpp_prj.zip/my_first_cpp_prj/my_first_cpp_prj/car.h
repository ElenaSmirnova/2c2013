#pragma once

#include <cstdio>

class car
{
public:
	int speed;
	int get_speed();
	car(int speed);
	~car(void);
};


class Train {
public:
	mutable int x;
	void choo() const {
		x = 23;
		printf("Choo, choo, mother****er!\n");
		fflush(stdout);
		for (int i = 0; i < 10; i++) {
			static int n = 1;
			++n;
			printf("%d\n", n);
		}
	}
};

